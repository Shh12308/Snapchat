# Mr28 - SNAPCHAT-SPAM - Account verification
[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)



##  Important 
Set Your Id and Bot Token for Telegram in [ Send.php ] page .




Created in 2020/August/14::Friday:: 11:36:07 AM




- PC 
![program pic](https://github.com/JUSTSAIF/SNAPCHAT-SPAM/blob/main/Pics/1.png?raw=true)






- Done
![program pic](https://github.com/JUSTSAIF/SNAPCHAT-SPAM/blob/main/Pics/3.png?raw=true)


- Mobile 
![program pic](https://github.com/JUSTSAIF/SNAPCHAT-SPAM/blob/main/Pics/2.png?raw=true)




## Contact
My Instagarm : [@qq_iq](https://www.instagram.com/qq_iq) Add Me :)🖤
